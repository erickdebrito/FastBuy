<!DOCTYPE html>
<html>
    <head>
       
        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                display: table;
                font-weight: 30;
                font-family: 'Lato';
            }
        </style>
    </head>
    <body>
        <div>
            <h1>Bem vindo à FastBuy!<BR>
             Sua melhor compra em um supermercado!..Para terminar seu cadastro, clique no link abaixo.</h1>
            <a href="http://www.html.net/">colocar o numero do hash aqui</a>
        </div>
    </body>
</html>
