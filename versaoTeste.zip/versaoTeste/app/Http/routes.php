<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::group(['prefix' => 'auth'], function () {

	Route::any('/Authenticate/{email}/{password}', ['uses' => 'AuthController@authenticate']);

	Route::any('/signup', ['uses' => 'AuthController@store']);
});

Route::group(['prefix' => 'produtos'], function () {

	Route::any('/listarProdutos/{id}', ['uses' => 'ProdutosController@listarProdutos']);

	Route::any('/buscarSupermercado/{id}', ['uses' => 'ProdutosController@buscarSupermercado']);
});

Route::any('/teste/{email}/{nome}', 'AuthController@index');

Route::any('/testeBase64/{id}', 'ProdutosController@store');

Route::group(['prefix' => 'carrinhoCompra'], function () {

	Route::any('/insereCarrinhoCompra/', 
		['uses' => 'CarrinhoController@adicionaCarrinho']);

	Route::any('/buscaItensCarrinho/{id_user}/{id_supermercado}', 
		'CarrinhoController@buscaProdutosCarrinho');
});

Route::group(['prefix' => 'produtosFavoritos'], function () {

	Route::any('/insereProdutoFavorito/', 
		['uses' => 'ProdutosFavoritosController@adicionaProdutoFavorito']);

	Route::any('/buscaProdutosFavoritos/{id_user}/{id_supermercado}', 
		'ProdutosFavoritosController@buscaProdutosFavoritos');
});

Route::group(['prefix' => 'pedidosUsuario'], function () {

	Route::any('/inserePedidoUsuario/{id_user}/{id_supermercado}', 
		'PedidosController@adicionaPedido');

	Route::any('/buscaPedidos/{id_user}/{id_supermercado}', 
		'PedidosController@buscaPedidos');
});

//Route::get('/Authenticate/{email}/{password}', 'AuthController@authenticate(email, password)');

