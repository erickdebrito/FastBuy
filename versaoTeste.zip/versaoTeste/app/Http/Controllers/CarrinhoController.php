<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class CarrinhoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function adicionaCarrinho(Request $request)
    {
        $carrinhosUsuario = DB::connection('FastBuy')->collection('users')->where('_id', $request->input('id_user'))->select('carrinhos')->get();
        $carrinhos = array_column($carrinhosUsuario, 'carrinhos');

        if(empty($carrinhos[0])){
            $novoCarrinho = array( 
                "id_supermercado" => $request->input('id_supermercado'),
                "produtos" => array()
            );
    
            $produto = array( 
                "id_produto" => $request->input('id_produto'),
                "id_supermercado" => $request->input('id_supermercado'),
                "nome" => $request->input('nome'),
                "information" => $request->input('information'),
                "grupo_pai" => $request->input('grupo_pai'),
                "grupo_filho" => $request->input('grupo_filho'),
                "price" => $request->input('price'),
                "codigoImagemBase64" => $request->input('codigoImagemBase64'),
                "quantidade" => $request->input('quantidade')
            );
            array_push($novoCarrinho['produtos'], $produto);

            return $result = DB::connection('FastBuy')->collection('users')->where('_id', $request->input('id_user'))
                ->push('carrinhos', $novoCarrinho);
        } else {
            $existe = false;
            foreach($carrinhos[0] as &$carrinho) {  
                if($carrinho['id_supermercado'] == $request->input('id_supermercado') && $existe == false){
                    $produto = array( 
                        "id_produto" => $request->input('id_produto'),
                        "id_supermercado" => $request->input('id_supermercado'),
                        "nome" => $request->input('nome'),
                        "information" => $request->input('information'),
                        "grupo_pai" => $request->input('grupo_pai'),
                        "grupo_filho" => $request->input('grupo_filho'),
                        "price" => $request->input('price'),
                        "codigoImagemBase64" => $request->input('codigoImagemBase64'),
                        "quantidade" => $request->input('quantidade')
                    );
                    array_push($carrinho['produtos'], $produto);
                    $existe = true;
                }
            }
            if($existe == false){
                $novoCarrinho = array( 
                    "id_supermercado" => $request->input('id_supermercado'),
                    "produtos" => array()
                );
    
                $produto = array( 
                    "id_produto" => $request->input('id_produto'),
                    "id_supermercado" => $request->input('id_supermercado'),
                    "nome" => $request->input('nome'),
                    "information" => $request->input('information'),
                    "grupo_pai" => $request->input('grupo_pai'),
                    "grupo_filho" => $request->input('grupo_filho'),
                    "price" => $request->input('price'),
                    "codigoImagemBase64" => $request->input('codigoImagemBase64'),
                    "quantidade" => $request->input('quantidade')
                );
                array_push($novoCarrinho['produtos'], $produto);

                return $result = DB::connection('FastBuy')->collection('users')->where('_id', $request->input('id_user'))
                    ->push('carrinhos', $novoCarrinho);
            }
            return $result = DB::connection('FastBuy')->collection('users')->where('_id', $request->input('id_user'))
            ->update(['carrinhos' => $carrinhos[0]]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function buscaProdutosCarrinho($id_user, $id_supermercado)
    {
        $header = array (
            'Content-Type' => 'application/json; charset=UTF-8',
            'charset' => 'utf-8'
        );

        $carrinhosUsuario = DB::connection('FastBuy')->collection('users')->where('_id', $id_user)
            ->select('carrinhos')->get();
        $carrinhos = array_column($carrinhosUsuario, 'carrinhos');
        $produtos = null;

        foreach($carrinhos[0] as &$carrinho) {  
            if($carrinho['id_supermercado'] == $id_supermercado){
                $produtos = $carrinho['produtos'];
            }
        }

        return response()->json( $produtos, 200, $header, JSON_UNESCAPED_UNICODE);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
