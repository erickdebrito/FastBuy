<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class PedidosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function adicionaPedido($id_user, $id_supermercado)
    {
        
        $novoPedido = array( 
            "id_supermercado" => $id_supermercado,
            "data_hora_pedido" => \Carbon\Carbon::now(),
            "produtos" => array()
        );
    
        $produto = array( 
            "id_produto" => '2317325', 
            "nome" => 'teste', 
            "id_supermercado" => '985894376843',
            "quantidade" => 10
            //"id_produto" => $request->input('id_produto'), 
            //"nome" => $request->input('nome'), 
            //"id_supermercado" => $request->input('id_supermercado'),
            //"quantidade" => $request->input('quantidade')
        );
        array_push($novoPedido['produtos'], $produto);

        return $result = DB::connection('FastBuy')->collection('users')->where('_id', $id_user)
            ->push('pedidos', $novoPedido);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function buscaPedidos($id_user, $id_supermercado)
    {
        $header = array (
            'Content-Type' => 'application/json; charset=UTF-8',
            'charset' => 'utf-8'
        );
        $pedidosUsuario = DB::connection('FastBuy')->collection('users')->where('_id', $id_user)
            ->select('pedidos')->get();
        $pedidos = array_column($pedidosUsuario, 'pedidos');
        $pedidosRealizados = [];

        foreach($pedidos[0] as &$pedido) {  
            // especificar dinamicamente no parametro "collection" qual supermercado a ser pesquisado!
            $supermercadoSupermercado = DB::connection('FastBuy')->collection('supermercadoExpinheiro')->get(); 
            $supermercado = $supermercadoSupermercado[0];
            $data_hora_compra = $pedido['data_hora_pedido'];
            $substr = substr($data_hora_compra['date'], 0, 19);
            $pedidorealizado = array( 
                "id_supermercado" => $id_supermercado,
                "nomeSupermercado" => $supermercado['nome'],
                "data_hora_compra" => $substr, 
                "valorTotal" => $pedido['valorTotal'],
                "codigoImagemBase64" => $supermercado['codigoImagemBase64']
            );
            array_push($pedidosRealizados, $pedidorealizado);
        }
        return response()->json( $pedidosRealizados, 200, $header, JSON_UNESCAPED_UNICODE);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
