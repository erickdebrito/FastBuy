<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class ProdutosFavoritosController extends Controller
{
    /**
     * Store the resources.
     *
     * @return \Illuminate\Http\Response
     */
    public function adicionaProdutoFavorito(Request $request)
    {
        $favoritosUsuario = DB::connection('FastBuy')->collection('users')->where('_id', $request->input('id_user'))
            ->select('favoritos')->get();
        $favoritos = array_column($favoritosUsuario, 'favoritos');

        if(empty($favoritos[0])){
            $novoFavoritos = array( 
                "id_supermercado" => $request->input('id_supermercado'),
                "produtosFavoritos" => array()
            );
    
            $produtoFavorito = array( 
                "id_produto" => $request->input('id_produto'),
                "id_supermercado" => $request->input('id_supermercado'),
                "nome" => $request->input('nome'),
                "information" => $request->input('information'),
                "grupo_pai" => $request->input('grupo_pai'),
                "grupo_filho" => $request->input('grupo_filho'),
                "price" => $request->input('price'),
                "codigoImagemBase64" => $request->input('codigoImagemBase64'),
                "quantidade" => $request->input('quantidade')
            );
            array_push($novoFavoritos['produtosFavoritos'], $produtoFavorito);

            return $result = DB::connection('FastBuy')->collection('users')->where('_id', $request->input('id_user'))
                ->push('favoritos', $novoFavoritos);
        } else {
            $existe = false;
            foreach($favoritos[0] as &$favorito) {  
                if($favorito['id_supermercado'] == $request->input('id_supermercado') && $existe == false){
                    $produtoFavorito = array( 
                        "id_produto" => $request->input('id_produto'),
                        "id_supermercado" => $request->input('id_supermercado'),
                        "nome" => $request->input('nome'),
                        "information" => $request->input('information'),
                        "grupo_pai" => $request->input('grupo_pai'),
                        "grupo_filho" => $request->input('grupo_filho'),
                        "price" => $request->input('price'),
                        "codigoImagemBase64" => $request->input('codigoImagemBase64'),
                        "quantidade" => $request->input('quantidade')
                    );
                    array_push($favorito['produtosFavoritos'], $produtoFavorito);
                    $existe = true;
                }
            }
            if($existe == false){
                $novoFavoritos = array( 
                    "id_supermercado" => $request->input('id_supermercado'),
                    "produtosFavoritos" => array()
                );
    
                $produtoFavorito = array( 
                    "id_produto" => $request->input('id_produto'),
                    "id_supermercado" => $request->input('id_supermercado'),
                    "nome" => $request->input('nome'),
                    "information" => $request->input('information'),
                    "grupo_pai" => $request->input('grupo_pai'),
                    "grupo_filho" => $request->input('grupo_filho'),
                    "price" => $request->input('price'),
                    "codigoImagemBase64" => $request->input('codigoImagemBase64'),
                    "quantidade" => $request->input('quantidade')
                );

                array_push($novoFavoritos['produtosFavoritos'], $produtoFavorito);

                return $result = DB::connection('FastBuy')->collection('users')->where('_id', $request->input('id_user'))
                    ->push('favoritos', $novoFavoritos);
            }
            return $result = DB::connection('FastBuy')->collection('users')->where('_id', $request->input('id_user'))
                ->update(['favoritos' => $favoritos[0]]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function buscaProdutosFavoritos($id_user, $id_supermercado)
    {
        $header = array (
            'Content-Type' => 'application/json; charset=UTF-8',
            'charset' => 'utf-8'
        );

        $favoritosUsuario = DB::connection('FastBuy')->collection('users')->where('_id', $id_user)
            ->select('favoritos')->get();
        $favoritos = array_column($favoritosUsuario, 'favoritos');
        $produtosFavoritos = null;

        foreach($favoritos[0] as &$favorito) {  
            if($favorito['id_supermercado'] == $id_supermercado){
                $produtosFavoritos = $favorito['produtosFavoritos'];
            }
        }

        return response()->json( $produtosFavoritos, 200, $header, JSON_UNESCAPED_UNICODE);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
