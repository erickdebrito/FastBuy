<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Mail;
use Crypt;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Contracts\Encryption\DecryptException;

class AuthController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($email, $nome)
    {
        //$document = array( 
        //    "title" => "MongoDB", 
        //    "description" => "database", 
        //    "likes" => 100,
        //    "url" => "http://www.tutorialspoint.com/mongodb/",
        //    "by", "tutorials point"
        //);
        //$inserido = DB::connection('mongodb')->collection('migrations')->insert($document);
        //print_r($inserido);
        $mailVal = array( 
            "name" => $nome, 
            "email" => $email, 
        );

        Mail::send('email.welcome', ['email' => $email], function ($m) use ($mailVal) {
            $m->from('erickbrlucena@hotmail.com', 'FastBuy');

            $m->to(array_column($mailVal, 'email'), array_column($mailVal, 'name'))->subject('FastBuy confirmação de e-mail');
        });
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $header = array (
                'Content-Type' => 'application/json; charset=UTF-8',
                'charset' => 'utf-8'
            );
        $pass = Crypt::encrypt($request->input('password'));
        $user = array( 
            "name" => $request->input('nome'), 
            "email" => $request->input('email'), 
            "password" => $pass,
            "data_nascimento" => $request->input('dataNascimento'),
            "genero" => $request->input('genero'),
            "remember_token" => null,
            "data_cadastro" => \Carbon\Carbon::now(), 
            "carrinhos" => [],
            "produtosFavoritos" => [],
            "pedidos" => [],
            "active" => 1
        );
        //$mailVal = array( 
        //    "name" => $request->input('nome'), 
        //    "email" => $request->input('email'), 
        //);

        $inserido = DB::connection('FastBuy')->collection('users')->insert($user);

        //Mail::send('email.welcome', ['email' => $request->input('email')], function ($m) use ($mailVal) {
        //    $m->from('erickbrlucena@hotmail.com', 'FastBuy');
        //
        //    $m->to(array_column($mailVal, 'email'), array_column($mailVal, 'name'))->subject('FastBuy confirmação de e-mail');
        //});

        return response()->json( $inserido, 200, $header, JSON_UNESCAPED_UNICODE);
    }

    /**
     * Display the specified resource.
     /*
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //$migrations = new connection();
        $resultado = DB::connection('FastBuy')->collection('migrations')->get(); 
        print_r($resultado);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function authenticate($email, $password)
    {
        $header = array (
                'Content-Type' => 'application/json; charset=UTF-8',
                'charset' => 'utf-8'
            );
        $user = DB::connection('FastBuy')->collection('users')->where('email', $email)->where('active', 1)->get();
        if(!empty($user)){
        
            $pass = array_column($user, 'password');
            try {
                $decrypted = Crypt::decrypt($pass[0]);
            } catch (DecryptException $e) {
             //
            }
            if($decrypted == $password){
                return response()->json($user , 200, $header, JSON_UNESCAPED_UNICODE);
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }
}
