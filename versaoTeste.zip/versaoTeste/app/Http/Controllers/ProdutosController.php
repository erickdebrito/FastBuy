<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class ProdutosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function listarProdutos($id)
    {
        $header = array (
                'Content-Type' => 'application/json; charset=UTF-8',
                'charset' => 'utf-8'
            );
        $produtos = DB::connection('FastBuy')->collection('pdtsSMExpinheiro')->where('id_supermercado', $id)->get();
        
        return response()->json($produtos , 200, $header, JSON_UNESCAPED_UNICODE); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function buscarSupermercado($id)
    {
        $header = array (
                'Content-Type' => 'application/json; charset=UTF-8',
                'charset' => 'utf-8'
            );
        $supermercado = DB::connection('FastBuy')->collection('supermercadoExpinheiro')->where('_id', $id)->get();
        
        return response()->json($supermercado , 200, $header, JSON_UNESCAPED_UNICODE); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($id)
    {
        $imagem = file_get_contents('C:/Users/erick/Desktop/images.jpg');

        $img = array( 
            "codigoImagemBase64" => base64_encode($imagem)
        );

        $result = DB::connection('FastBuy')->collection('supermercadoExpinheiro')
            ->where('_id', $id)->insert($img);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
